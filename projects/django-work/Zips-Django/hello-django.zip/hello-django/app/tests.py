from urllib import response
from django.test import SimpleTestCase

# Create your tests here.
class TestHelloView(SimpleTestCase):
    def test_hello_alucard(self):
        response=self.client.get("/hello/Alucard/")
        self.assertContains(response, "Hello Alucard!")
        
    def test_hello_nate(self):
        response=self.client.get("/hello/nate/")
        self.assertContains(response, "Hello nate!")

# class TestRandom_between(SimpleTestCase):
#     def test_random_between_views(self):
#         response=self.client.get("random-between/<int:lo>/<int:hi>/")
#         self.assertContains(response, "...")

# class TestRollDie(SimpleTestCase):
#     def test_roll_die_views(self):
#         response=self.client.get("roll-die/9/")
#         self.assertTrue(response, 9)