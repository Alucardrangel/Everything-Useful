import random
from django.http.response import HttpResponse
from django.http.request import HttpRequest


def hello_views(request, name) -> HttpResponse:
   return HttpResponse(f"Hello {name}!")


def random_between_views(request, lo, hi):
   return HttpResponse(random.randint(lo,hi))



def roll_die_views(request, sides):
   roll = random.randint(1, (int(sides)))
   return HttpResponse(roll)

