
from django.contrib import admin
from django.urls import path
from app.views import hello_views, roll_die_views, random_between_views



urlpatterns = [
    path("roll-die/<int:sides>/", roll_die_views),
    path("random-between/<int:lo>/<int:hi>/", random_between_views),
    path("hello/<name>/",hello_views),
    path("admin/", admin.site.urls),
]
